<?php 
include 'co.php'; 
include 'vsheader.php';

$login=$_SESSION['login'];
$type=$_SESSION['type'];
$id=$_SESSION['userid'];
if($login)
{
  ?>
<!DOCTYPE html>
<html>
 <head>
  <title>Webslesson Tutorial | Bootstrap Multi Select Dropdown with Checkboxes using Jquery in PHP</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css" />
 </head>
 <body>
  <br /><br />
  <div class="container" style="width:600px;">
  

   
<form name="myform" method="post" class="form-container" id="myform">

<h2 >Camp Routines</h2><br/>
   <div class="form-group">
      
    <div class="form-group">
     <label>Actvity name</label>
     
     <?php
   
          
  // $sq=mysqli_query($co,"select * from register  ");
  // $r=mysqli_fetch_array($sq,MYSQLI_ASSOC);
  // $em=$r['name'];

           
          
  $sq=mysqli_query($co,"select * from sacti  ");
  

  
    ?>

   
    <select id="framework" name="framework[]" required="" class="form-control">
                       <?php

while($row=mysqli_fetch_array($sq))
                      {

                        ?>
                   <option value="<?php echo $row['sactiname'];?>"><?php echo $row['sactiname'];?></option>
           
                      <?php
                      }
   ?>
    </div>
 <div class="form-group">
     
          
            <div class="form-group">
            <label>Date *</label>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
            <input id="date" name="date" type="date"    data-validation="required"  required="" " ><script>
          function validateform1()
          {
var x=document.forms["myform"]["date"].value;
if(x=="")
{
alert("Please Fill date ");
document.getElementById("date").focus();
return false;
}


return true;
      }
   </script>
            </div>


    <div class="form-group">
     <label>Group name</label>
     
     <?php
   
          
  // $sq=mysqli_query($co,"select * from register  ");
  // $r=mysqli_fetch_array($sq,MYSQLI_ASSOC);
  // $em=$r['name'];

           
          
  $sq=mysqli_query($co,"select * from groupp where gstatus=1  ");
  

  
    ?>

   
    <select id="frame" name="frame[]" required="" class="form-control">
                       <?php

while($row=mysqli_fetch_array($sq))
                      {

                        ?>
                   <option value="<?php echo $row['groupname'];?>"><?php echo $row['groupname'];?></option>
           
                      <?php
                      }
   ?>
    </div>
    <div class="form-group">
     <input type="submit" class="btn btn-success center" name="submit" value="Submit" />
    </div>
   </form>
   <br />
  </div>
 </body>
</html>

<script>
$(document).ready(function(){
 $('#framework').multiselect({
  nonSelectedText: 'Select Activity ',
  enableFiltering: true,
  enableCaseInsensitiveFiltering: true,
  buttonWidth:'200px'
 });
 
 
  });

 
 

</script>
  
<script>
$(document).ready(function(){
 $('#frame').multiselect({
  nonSelectedText: 'Select group ',
  enableFiltering: true,
  enableCaseInsensitiveFiltering: true,
  buttonWidth:'200px'
 });
 
 
  });

 
 

</script>

 
 

</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js" ></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/3.3.1/jquery-ui.min.js" ></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script>
  jQuery.validator.addMethod("lettersonly", function(value, element) {
  return this.optional(element) || /^[a-z]+$/i.test(value);
}, "Letters only please");
  jQuery.validator.addMethod("validDate", function(value, element) {
        return this.optional(element) || moment(value,"DD/MM/YYYY").isValid();
    }, "Please enter a valid date in the format DD/MM/YYYY");
   








var $registrationForm = $('#myform');
if($registrationForm.length){
  $registrationForm.validate({
      rules:{
          //username is the name of the textbox
          framework: {
              required: true,
              //alphanumeric is the custom method, we defined in the above
            
          },
       
        date: {
              required: true,
          
           
          },  
         
        frame: {
              required: true,
          
           
          },    
      },
      messages:{
          framework: {
              //error message for the required field
              required: 'choose activity',
            
          },
                 date: {
              //error message for the required field
              required: 'choose date',
              
            
          },
       
       frame: {
              //error message for the required field
              required: 'choose group name'
              
            
          },

      },

  });
}
  </script>
  
</body>
  </html>


<?php
  if(isset($_POST['submit']))
   {
     $sug=$_POST['date'];
    

  
    if(isset($_POST['framework'])){
    $framework = '';
 foreach($_POST["framework"] as $row)
 {
  $framework .= $row . ', ';
 } $framework = substr($framework, 0, -2);


if(isset($_POST['frame'])){
    $frame = '';
 foreach($_POST["frame"] as $row)
 {
  $frame .= $row . ', ';
 } $frame = substr($frame, 0, -2);



 $query = "INSERT INTO camp(cdate,gname,cactivity,cstatus) VALUES('".$sug."','".$frame."','".$framework."',0)";
 if(mysqli_query($co, $query))
 

{
  
      echo "<script> alert('Success');
           window.location='cmproutine.php'</script>";
}
}
 }
 } 
?>
 <?php
}
else
header("location:login.php");
?>  