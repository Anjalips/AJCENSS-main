<?php

namespace App\Http\Controllers;
use App\Student;
use App\de;
use Illuminate\Http\Request;

class StudentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
		$student = student::all();
		return view('student.index',compact('student'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
		return view('student.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        /**
		$request->validate([
        'stud_name'=>'required',
        'stud_age'=> 'required|integer',
        'stud_course' => 'required',
        'stud_department' => 'required'
      ]);
	  */
      $student = new student([
        'name' => $request->get('stud_name'),
        'age'=> $request->get('stud_age'),
        'course'=> $request->get('stud_course'),
        'department'=> $request->get('stud_department')
      ]);
	  $demo = new de([
        'name' => $request->get('stud_name')
      ]);
      $student->save();
	    $demo->save();
      return redirect('/student')->with('success', 'student  has been added');
   
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
		$student = student::find($id);
		return view('student.edit',compact('student'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
		$request->validate([
        'stud_name'=>'required',
        'stud_age'=> 'required|integer',
        'stud_course' => 'required',
        'stud_department' => 'required'
      ]);

      $student = student::find($id);
      $student ->name = $request->get('stud_name');
      $student ->age = $request->get('stud_age');
      $student ->course = $request->get('stud_course');
      $student ->department = $request->get('stud_department');
      $student ->save();

      return redirect('/student')->with('success', 'Student details has been updated');
    
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
		$student = student::find($id);
     $student->delete();

     return redirect('/student')->
     with('success', 'Student has been
      deleted Successfully');
    }
}
