<?php

namespace App\Http\Controllers;
use App\Admin;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
		$admin = admin::all();
		return view('admin.index',compact('admin'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
		return view('admin.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
		
		$request->validate([
        'admin_name'=>'required',
        'admin_emailid'=> 'required',
        'admin_phone' => 'required'
        
      ]);
      $admin = new admin([
        'name' => $request->get('admin_name'),
        'emailid'=> $request->get('admin_emailid'),
        'phone'=> $request->get('admin_phone'),
     
      ]);
      $admin->save();
      return redirect('/admin')->with('success', 'admin  has been added');
   
    }

    

     /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
		
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
		$admin = admin::find($id);
		return view('admin.edit',compact('admin'));
		
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
		$request->validate([
        'admin_name'=>'required',
        'admin_emailid'=> 'required',
        'admin_phone' => 'required',
        
      ]);

      $admin = admin::find($id);
      $admin ->name = $request->get('admin_name');
      $admin ->emailid = $request->get('admin_emailid');
      $admin ->phone = $request->get('admin_phone');
     
      $admin ->save();

      return redirect('/admin')->with('success', 'Admin details has been updated');
		
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
		
$admin = admin::find($id);
     $admin->delete();

     return redirect('/admin')->
     with('success', 'admin has been
      deleted Successfully');
    }
}
