<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class de extends Model
{
    //
	protected $fillable=['name'];
}
