<?php $__env->startSection('content'); ?>
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="card uper">
  <div class="card-header">
    Add Student
  </div>
  <div class="card-body">
    <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div><br />
    <?php endif; ?>
      <form method="post" action="<?php echo e(route('student.store')); ?>">
          <div class="form-group">
              <?php echo csrf_field(); ?>
              <label for="name">Student Name:</label>
              <input type="text" class="form-control" name="stud_name"/>
          </div>
          <div class="form-group">
              <label for="age">Age</label>
              <input type="text" class="form-control" name="stud_age"/>
          </div>
          <div class="form-group">
              <label for="course">Course</label>
              <input type="text" class="form-control" name="stud_course"/>
          </div>
          <div class="form-group">
              <label for="department">Department</label>
              <input type="text" class="form-control" name="stud_department"/>
          </div>

          <button type="submit" class="btn btn-primary">Add</button>
      </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\mainproject\nss\resources\views/student/create.blade.php ENDPATH**/ ?>