<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
include 'co.php';
include 'vsheader.php';

$login=$_SESSION['login'];
$type=$_SESSION['type'];

if($login)
{
  ?>
<!DOCTYPE HTML>
<html>
<head>
  <!DOCTYPE HTML>
<html>
<head>



<title>Add Notices</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Shoppy Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<!--js-->
<script src="js/jquery-2.1.1.min.js"></script> 
<!--icons-css-->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Carrois+Gothic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Work+Sans:400,500,600' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" 
integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" 
integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" 
crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" 
integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
 crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
 integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
 crossorigin="anonymous"></script>






 
    <div class="col-md-4 col-sm-4 col-xs-12 "></div>
    <div class="col-md-4 col-sm-4 col-xs-12  box">
      
        <form name="myform" method="post" class="form-container" id="myform" onsubmit="return validateform()">
          
          <h2 ><center>Activity</center> </h2>
 
        </script><table width="100%" >
<tr>  


<td><center>Activity Name*<center></td>
<td><input id="acname" name="acname" class="form-control" type="text" data-validation="time"  onchange="return validateform1()" required=""></center></td>
<script>
          function validateform1()
          {
var x=document.forms["myform"]["acname"].value;
if(x=="")
{
alert("Please Fill activity name");
document.getElementById("acname").focus();
return false;
}
var x=new RegExp("^[a-zA-z ]*$");
if(!x.test(document.myform.acname.value))
{
  alert("Enter name with characters only");
  myform.acname.focus();
  document.getElementById("acname").value="";
  return false;
}

return true;
      }
          
          </script> <span id="error_notice" class="text-danger"></span>
<td><center>&nbsp&nbsp&nbsp&nbsp</center></td><td><center>place*</center></td>
<td><center><input id="place" name="place" class="form-control" type="text" data-validation="place"></center></td>
 <span id="error_notice" class="text-danger"></span>
</tr>
<tr><td><center>&nbsp&nbsp</center></td></tr>
<tr>
<td><center>Last Date To Apply*</center></td>
<td><center><input id="date" name="date" class="form-control" type="date" data-validation="date" onchange="return validateform3()"><center></td>
<td><center>&nbsp&nbsp&nbsp&nbsp</center></td> <span id="error_notice" class="text-danger"></span>
<script>
        function validateform3()
        {
var x=document.forms["myform"]["date"].value;
if(x=="")
{
alert("Please Fill Date ");
document.getElementById("date").focus();
return false;
}
var GivenDate =document.forms["myform"]["date"].value;
var CurrentDate = new Date();
GivenDate = new Date(GivenDate);

if(GivenDate < CurrentDate){
    alert('Given date is less than the current date.');
  document.getElementById("date").focus();
  document.getElementById("date").value="";
  return false;
}

return true;
        }       
        </script>
<td><center>Time*</center></td>
<td><center><input id="time" name="time" class="form-control" type="time" data-validation="time" required></center></td>
 <span id="error_notice" class="text-danger"></span></tr>

<tr><td><center>&nbsp&nbsp</center></td></tr>
<tr>
<td><center>Volunteers Needed*</center></td>
<td><center><input id="vno" name="vno" class="form-control" type="number" data-validation="vno"  onchange="return validateform13()" required><center></td><td><center>&nbsp&nbsp&nbsp&nbsp</center></td> <span id="error_notice" class="text-danger"></span>
<script>
   function validateform13()
        {
if( document.myform.vno.value == "" ||
           isNaN( document.myform.vno.value) ||
           document.myform.vno.value <1 )
   {
     alert( "Please provide a Volunteer No in valid numbers." );
     document.myform.vno.focus() ;
     return false;
   }
return true;
}
</script>


<td><center>Hour Of Work*</center></td>
<td><center><input id="how" name="how" class="form-control" type="number" data-validation="how"  onchange="return validateform14()" required><center></td><td><center>&nbsp&nbsp&nbsp&nbsp</center></td> <span id="error_notice" class="text-danger"></span>
<script>
   function validateform14()
        {
if( document.myform.how.value == "" ||
           isNaN( document.myform.how.value) ||
           document.myform.how.value <1 )
   {
     alert( "Please provide a hour of work in valid hours." );
     document.myform.how.focus() ;
     return false;
   }
return true;
}
</script></td></tr>
<tr>
<td><center>Description*</center></td>
<td><center><input id="dec" name="dec" class="form-control" type="text" data-validation="dec" onchange="return validateform2()" required><center></td>

<script>
          function validateform2()
          {
var x=document.forms["myform"]["dec"].value;
if(x=="")
{
alert("Please Fill description ");
document.getElementById("dec").focus();
return false;
}
var x=new RegExp("^[a-zA-z ]*$");
if(!x.test(document.myform.dec.value))
{
  alert("Enter desctiption with characters only");
  myform.dec.focus();
  document.getElementById("dec").value="";
  return false;
}

return true;
      }
          
          </script>
 <span id="error_notice" class="text-danger"></span><td><center>&nbsp&nbsp&nbsp&nbsp</center></td>

<td><center></center></td>
<td><center>
</center></td></tr>
<tr>
<td><center>&nbsp&nbsp&nbsp&nbsp</center></td>
<td><center>&nbsp&nbsp&nbsp&nbsp</center></td>
</tr>
<tr><td><center>&nbsp&nbsp&nbsp&nbsp</center></td>
<td><center>&nbsp&nbsp&nbsp&nbsp</center></td>
</tr>
<tr>
<td><center>&nbsp&nbsp&nbsp&nbsp</center></td>
<td><center>&nbsp&nbsp&nbsp&nbsp</center></td>
<td rowspan="4"><button id="submit" type="submit" name="submit" value="Add activity" class="btn btn-success center">&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp  &nbsp&nbspAdd Activity &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</button></td>
</tr>
</center>


      
        </form>

      </div>
      
      <div class="col-md-4 col-sm-4 col-xs-12"></div>
    </div >
  </div>
 

  </form>

</font>
 
 


<!--inner block end here-->
<!--pop-up-grid-->
                       <div id="popup">
                <div id="small-dialog" class="mfp-hide">
              
                </div>
              
                
<!--pop-up-grid-->
<!--copy rights start here-->
  
<!--COPY rights end here-->
</div>
</div>
<!--slider menu-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js" ></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/3.3.1/jquery-ui.min.js" ></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script>
  jQuery.validator.addMethod("lettersonly", function(value, element) {
  return this.optional(element) || /^[a-z]+$/i.test(value);
}, "Letters only please");
    jQuery.validator.addMethod("noSpace", function(value, element) {
    return value == '' || value.trim().length != 0;
}, "No space please and don't leave it empty");
jQuery.validator.addMethod("customEmail", function(value, element) {
  return this.optional( element ) || /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test( value );
}, "Please enter valid email address!");



jQuery.validator.addMethod("passstrength", function(value, element) {
    return this.optional(element) || /([0-9])/ && /([a-zA-Z])/ && /([~,!,@,#,$,%,^,&,*,-,_,+,=,?,>,<])/.test(value);});


jQuery.validator.addMethod("alphabetsnspace", function(value, element) {
    return this.optional(element) || /^[a-zA-Z ]*$/.test(value);},"Invalid!");

jQuery.validator.addMethod("validDate", function(value, element) {
        return this.optional(element) || moment(value,"DD/MM/YYYY").isValid();
    }, "Please enter a valid date in the format DD/MM/YYYY");


jQuery.validator.addMethod("phoneno", function(phone_number, element) {
          phone_number = phone_number.replace(/\s+/g, "");
          return this.optional(element) || phone_number.length > 9 && 
          phone_number.match(/^((\+[6-9]{1,4}[ \-]*)|(\([0-9]{2,3}\)[ \-]*)|([0-9]{2,4})[ \-]*)*?[0-9]{3,4}?[ \-]*[0-9]{3,4}?$/);
      }, "<br />Please specify phone number");


$.validator.addMethod( "alphanumeric", function( value, element ) {
return this.optional( element ) || /^\w+$/i.test( value );
}, "Letters, and underscores only please" );

var $registrationForm = $('#myform');
if($registrationForm.length){
  $registrationForm.validate({
      rules:{
          //username is the name of the textbox
          
         place:{
            required: true,
             lettersonly: true
        },
    
    date:{
             required: true,
      },
          
         
          
      },
      messages:{
          
        /* lname:{
            required: 'Please enter the lname!'
         },*/
          place:{
            required: 'Enter place',
        lettersonly: 'characters only'
          },
       date:{
            required: 'Enter a valid date'
             },
      
        time:{
            required: 'Enter a valid time'
             },
      
          
          
      },

  });
}
  </script>
</head></body></html>
<?php
  if(isset($_POST['submit']))
   {
     $acname=$_POST['acname'];
     $place=$_POST['place'];
 $date=$_POST['date'];
     $time=$_POST['time'];
  
     $vno=$_POST['vno'];
 $how=$_POST['how'];
     $dec=$_POST['dec'];
    
     
    
    $sq="insert activity (activityname,aplace,adate,atime,vno,hourwork,description,astatus)values('$acname','$place','$date','$time','$vno','$how','$dec','0')";
if(mysqli_query($co,$sq))
{
  
      echo "<script> alert('Success');
           window.location='activity.php'</script>";
}
}
   
?>
<?php
}
else
header("location:login.php");
?>