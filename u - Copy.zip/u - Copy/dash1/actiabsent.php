<?php
include "co.php";
$b=$_GET['id'];
$bb=$_GET['id1'];
$res=mysqli_query($co,"select * from applyactivity where userid='$b'");
 while($row=mysqli_fetch_assoc($res))
{  

$et=$row['atte'];
}
$sql=mysqli_query($co,"update  applyactivity set atte='$bb',atstatus='0' where userid='$b'");

if ( $sql  ){
echo "<script>alert('Absent');
      window.location='activityatt.php';</script>";
}
else {
	echo "<script>alert('Error');</script>";
}
?>