
<?php
include "co.php";
$em=$_GET['id'];
$sql2="update eregister set estatus='1' where eid='$em'";
if(mysqli_query($co,$sql2))
{
echo "<script>alert('Approved');
      window.location='eregisterapprove.php'</script>";
}

	?>