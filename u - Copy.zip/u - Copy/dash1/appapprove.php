
<?php
include "co.php";
$em=$_GET['id'];
$sql2="update application set appstatus='1' where appid='$em'";
if(mysqli_query($co,$sql2))
{
echo "<script>alert('Approved');
      window.location='approveapp.php'</script>";
}
?>
