<!DOCTYPE html>
<html lang="en">
<head>
   <style>
    .navbar {
    overflow: hidden;
    background-color: gray;
    font-family: Arial, Helvetica, sans-serif;
}
.navbar a.active {
  background-color: #4CAF50;
  color: white;
}

.navbar a {
    float: right;
    font-size: 16px;
    color: white;
    text-align: center;
    padding: 18px 16px;
    text-decoration: none;
}
.navbar a:hover, .dropdown:hover .dropbtn {
    background-color: red;
}
</style>

</head>
<body class="barber_version">
<div class="navbar">

  

  <a href="login.php">Login</a>

                    
                    
                    
                   
                    

                    
                    
                    <a href="sregg.php">Sign Up</a>
  
  </div>

