
<?php
include "co.php";
$em=$_GET['id'];
$sql1=mysqli_query($co,"update applyactivity set apprstatus='1' where userid='$em'");
$sqll=mysqli_query($co,"update   registers set actiapprove='1' where userid='$em'");


if ( $sql1 && $sqll  ){
echo "<script>alert('Approved');
      window.location='poapplystudents.php';</script>";
}
else {
	echo "<script>alert('Error');</script>";
}
?>
