<?php
include 'co.php';

include 'vsheader.php';

$login=$_SESSION['login'];
$type=$_SESSION['type'];

if($login)
{
  ?>
<!DOCTYPE HTML>
<html>
<head>
  <style type="text/css">
    th{
      width: 150px;
      height: 50px;
      background-color:#4caf50;
      color: white;



    }
    td{
      width: 150px;
      height: 30px;
         text-align: center;

    }
    th,td{
      text-align: left;
      padding: 8px;
    }

  
    
    
  </style>
<title>Add Notices</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Shoppy Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<!--js-->
<script src="js/jquery-2.1.1.min.js"></script> 
<!--icons-css-->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Carrois+Gothic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Work+Sans:400,500,600' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" 
integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" 
integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" 
crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" 
integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
 crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
 integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
 crossorigin="anonymous"></script>




  <div class="blank">




<!--inner block start here-->
<!--<div class="inner-block"></div>-->

      <center><h1>Notice</h1></center>

<center>

<table border="0"  width="95%" >
<th >Matter</th>
   
    
    <th >Date</th>
    <th >Time</th>

  
   
    
  </tr>
<?php
 $q="select * from notice";
 $res=mysqli_query($co,$q);
while($row=mysqli_fetch_assoc($res))
{
  
  

?>

<tr>
<td> 
   <?php 
        echo $row['matter'];
    ?>a
  </td>
  <td> 
   <?php 
        echo $row['date'];
    ?>
  </td>
   <td> 
   <?php 
        echo $row['time'];
    ?>
  </td>



</tr>
<?php
}
?>

<!--slide bar menu end here-->

</body>
</html>

<?php
}
else
header("location:login.php");
?>

                      
            
