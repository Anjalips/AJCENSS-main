<?php
session_start();
$login=$_SESSION['login'];
$type=$_SESSION['type'];

if($login)
{
  ?>
<!DOCTYPE html>
<head>
<script>
function validate()
{
	
if(document.getElementById("old").value=="")

    {

     alert("Enter Your Old Password !!");

     document.getElementById("old").focus();

     return false;

    }


	if(document.getElementById("new").value=="")

    {

     alert("Enter New Password !!");

     document.getElementById("new").focus();

     return false;

    }

     if(document.getElementById("new").value.length<4)

    {

    alert("Password must be of 4 or more characters");

    document.getElementById("new").focus();

    return false;

    }

    if(document.getElementById("conf").value=="")

    {

     alert("Enter confirm password");

     document.getElementById("conf").focus();

     return false;

    }
	 var cpwd =document.getElementById("conf").value;

     var pwde=document.getElementById("new").value;

     var matchArray = pwde.match("cpwd").value;

     if (matchArray == null)

    {

               alert("Your confrim password seems incorrect. Enter Correct confirm password");

               document.getElementById("conf").focus();

               return false;

    }
	
return true;
}

</script>
<style>
.navbar {
    overflow: hidden;
    background-color: black;
    font-family: Arial, Helvetica, sans-serif;
}
.navbar a.active {
  background-color:green;
  color: white;
}

.navbar a {
    float: left;
    font-size: 16px;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}
.navbar a:hover, .dropdown:hover .dropbtn {
    background-color: red;
}
input[type=submit] {
    width: 30%;
  
    background-color: #4CAF50;
    color: white;
    padding: 10px 10px;
    margin: 8px 0;
    border: none;
    border-radius: 6px;
    cursor: pointer;
}

.header{
padding: 20px;
text-align: center;
background: gray;
color: white;
}
</style>
</head>
<body>
<div class="header">
<h1> AJCE NSS</h1><br>

</div>
 <?php echo "<font size=5 color=blue>Welcome $type ";?>
<div class="nvbar">
<a class="active"> <a href="logout.php">back</a>
</div>

<?php 
include("co.php");


if(isset($_POST['button']))
{

$old=$_POST["old"];
$new=$_POST["new"];
$conf=$_POST["conf"];

$o=md5($old);
$n=md5($new);
$c=md5($conf);
	if ($n==$c)
	{ 
	mysqli_query($co,"update login set password='$n' where password='$o'");
	?>
		<script>
		alert("successfully updated")
		window.location='login.php';
		</script>
		<?php
	}
	else
	{
		?>
		<script>
		alert("Password MisMatch")
		</script>
	
<?php
	}
}

	
	?>
    
 





<body>
<form action="" method="post">
<h1 align="center">Change Password</h1>
<p></p>
<table width="450" border="0" bgcolor="#D8D8D8" align="center">
  
  <tr>
  <tr>
    <th width="205" scope="row">Old password:&nbsp;</th>
    <td width="225"><input name="old" id="old" type="text" />&nbsp;</td>
  </tr>
  <tr>
    <th scope="row">New password:&nbsp;</th>
    <td><input name="new" id="new" type="password" />&nbsp;</td>
  </tr>
  <tr>
    <th scope="row">Confirm password:&nbsp;</th>
    <td><input name="conf" id="conf" type="password" />&nbsp;</td>
  </tr>
  <tr>
    <th colspan="2" scope="row"><input name="button" type="submit" value="submit" onclick="return validate()" />&nbsp;</th>
  </tr>

</table>

</form>
</body>

</html>
<?php
}
else
header("location:login.php");
?>
