<?php
include "co.php";
$b=$_GET['id'];
$sql=mysqli_query($co,"update applyapp set apprvstatus='0'   where userid='$b'");

if ( $sql  ){
echo "<script>alert('Removed');
      window.location='poapprovestudents.php';</script>";
}
else {
	echo "<script>alert('Error');</script>";
}
?>
