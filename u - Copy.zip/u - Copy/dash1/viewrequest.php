<?php
include 'co.php';
include 'vsheader.php';







$login=$_SESSION['login'];
$type=$_SESSION['type'];

if($login)
{
  ?>
<!DOCTYPE HTML>
<html>
<head>
    <style type="text/css">
    th{
      width: 150px;
      height: 50px;
      background-color:#4caf50;
      color: white;

    }
    td{
      width: 150px;
      height: 30px;
      

    }
    th,td{
      text-align: left;
      padding: 8px;
    }

  
    
    
  </style>
<title>Add Notices</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Shoppy Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<!--js-->
<script src="js/jquery-2.1.1.min.js"></script> 
<!--icons-css-->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Carrois+Gothic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Work+Sans:400,500,600' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" 
integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" 
integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" 
crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" 
integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
 crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
 integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
 crossorigin="anonymous"></script>



<div class="blank">
        
<!--heder end here-->
<!-- script-for sticky-nav -->
   
  
      <center><h1>New Request</h1></center>

 <!--$sql = "INSERT INTO `center`(`cen_name`,`place`) VALUES ('$cen_name','$place')";
     if(mysqli_query($con, $sql)) {
  
         }
     ?> -->
<center>

<table border="0"  width="95%" >

 <tr><th>Admission number</th>
    <th>Userid</th>
    <th>Name</th>
  <th>Class</th>
    <th>Year</th>
    <th>Address</th>
    <th>Experience</th>
  <th>Phone</th>
  <th>Gender</th>
  <th>Blood group</th>
  <th>Dob</th>
  <th>Email id</th>
  <th>Photo</th>
  <th>Id card</th>
  <th>Verify</th>
  <th>Reject</th>
    
  </tr>

<?php

$res=mysqli_query($co,"select * from registers  ");
while($row=mysqli_fetch_assoc($res))
{
  
  $lid=$row['userid'] ;
  $ap=$row['verifystatus'];
    $uid=$row['userid'];
  $sq=mysqli_query($co,"select emailid from login where userid='$lid' ");
  $r=mysqli_fetch_array($sq,MYSQLI_ASSOC);
  $em=$r['emailid'];
?>

<tr>
<td> 
   <?php 
        echo $row['adno'];
    ?>

  </td>

  <td> 
   <?php 
        echo $row['userid'];
    ?>
  </td>
<td>
<?php
echo $row['name'];
?>
</td>
<td>
<?php
echo $row['class'];
?>
</td>
<td>
<?php
echo $row['year'];
?>
</td>
<td>
<?php
echo $row['address'];
?>
</td>
<td>
<?php
echo $row['experience'];
?>
</td>
<td>
<?php
echo $row['phone'];
?>
</td>
<td>
<?php
echo $row['gender'];
?>
</td>
<td>
<?php
echo $row['bloodgroup'];
?>
</td>
<td>
<?php
echo $row['dob'];
?>
</td>
<td>
<?php
echo $r['emailid'];
?>
</td>
<td>
<img src="<?php echo $row['img'];?>" width=80%
  height=200%></td>
<td>
<img src="<?php echo $row['idcard'];?>" width=60%
  height=200%></td>&nbsp &nbsp &nbsp &nbsp
</td>
<td>
  <?php
    if($ap==1 && $lid==$uid){
       echo "Approved";
   }

   else { ?>
<button><a href="verify.php?id=<?php echo $lid; ?> ">verify</a></button>
</td><?php } 
?>
<td><?php
    if($ap==0 && $lid==$uid){
       echo "rejected";
   }

   else { ?>
<button><a href="requestreject.php?id=<?php echo $lid; ?>">Reject</a></button>
</td>
</tr>
<?php
}
?>
</body>

</html>
<?php
}
}
else
header("location:login.php");
?>
