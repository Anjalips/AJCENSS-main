
<?php
include "co.php";
 $em=$_GET['id'];
 $e=$_GET['id2'];
$sqd=mysqli_query($co,"select * from eregister where eid='$em' and estatus='1' ");
   $rr=mysqli_fetch_assoc($sqd);
  {
$ete=$rr['vote'];
   $t=$ete+1;

}
$sql=mysqli_query($co,"update  eregister set vote='$t' where eid='$em' and estatus='1' ");
$sql1=mysqli_query($co,"update  eregister set vstatus='1' where eid='$em' and estatus='1' ");
$sql2=mysqli_query($co,"update  registers set vostatus='1' where userid ='$e' and vostatus='0'");
if ( $sql && $sql1 && $sql2 ){
echo "<script>alert('Voted');
      window.location='election.php';</script>";
}
else {
	echo "<script>alert('Error');</script>";
}
?>