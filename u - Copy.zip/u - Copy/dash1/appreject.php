<?php
include "co.php";
$b=$_GET['id'];
$sql=mysqli_query($co,"update  application  set appstatus='0' where appid='$b'");

if ( $sql  ){
echo "<script>alert('Removed');
      window.location='approveapp.php';</script>";
}
else {
	echo "<script>alert('Error');</script>";
}
?>