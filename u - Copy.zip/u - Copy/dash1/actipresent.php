<?php
include "co.php";
$b=$_GET['id'];
$res=mysqli_query($co,"select * from applyactivity where userid='$b' and apprstatus='1'  ");
 while($row=mysqli_fetch_assoc($res))
{
  

  $emm=$row['activityid'];  

$et=$row['atte'];
}
    $sq=mysqli_query($co,"select * from activity where activityid='$emm' ");
   $r=mysqli_fetch_assoc($sq);
  {
   
   $mh=$r['hourwork'];
$res=mysqli_query($co,"select * from applyactivity where userid='$b' and apprstatus='1' and atstatus='1' ");
 while($row=mysqli_fetch_assoc($res))
{
  

  

$ett=$row['atte'];
}
   $t=$ett+$mh;

}
$sql=mysqli_query($co,"update  applyactivity set atte='$t',atstatus='1' where userid='$b' and apprstatus='1'");


if ( $sql   ){
echo "<script>alert('Present');
      window.location='activityatt.php';</script>";
}
else {
	echo "<script>alert('Error');</script>";
}
?>
