



<?php 
include 'co.php'; 
include 'sheader.php';


$login=$_SESSION['login'];
$type=$_SESSION['type'];
$id=$_SESSION['userid'];
if($login)
{
  $res=mysqli_query($co,"select  * from registers where  userid='$id' ");
 while($row=mysqli_fetch_assoc($res))
{  
$a=$row['name'];
$b=$row['adno'];
$c=$row['year'];
$d=$row['class'];
$s=$row['phone'];
$m=$row['dob'];

  ?>
<!DOCTYPE html>
<html>
<style>
body {
  font-family: Arial;
}

input[type=text], select {
  width: 100%;
  padding: 10px 15px;
  margin: 8px 0;
  display: block;
  border: 1px solid #ccc;
  border-radius: 3px;
  box-sizing:border-box;
}

input[type=submit] {
  width: 30%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 18px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

div.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 30px;
}
</style>
<body>
<form name="myform" action="eregister.php"  method="post" >
<h3>Nomination  Form</h3><input type="text" id="img"  name="img" >
<img src="<?php echo $row['img'];?>" width=20%
  height=20% ">

<div class="container">


    <label for="fname"> Name</label> 
    <input type="text" id="name" name="name" value="<?php
echo "$a"?> "> 


    
    <label for="adno">Admission Number</label> 
    <input type="text" id="adno" name="adno" value="<?php
echo "$b"?> "> 
 <label for="adno">Date of birth</label> 
    <input type="text" id="dob" name="dob" value="<?php
echo "$m"?> "> 
<label for="class">Class</label>
    <input type="text" id="class" name="class" > 
<label for="dept">Department</label> <input type="text" id="dept" name="dept"value="<?php
echo "$d"?> "> <br>
 
    <label for="phone">Phone Number</label>
      <input type="text" id="phone" name="phone" value="<?php
echo "$s"?> "> <br>
    <label for="emailid">Emailid</label><?php

$ress=mysqli_query($co,"select  *  from login where  userid='$id'");
 while($roww=mysqli_fetch_assoc($ress))
{  
$e=$roww['emailid'];

}
?>
    <input type="email" id="email" name="email" value="<?php
echo "$e"?> "> 
    <br>

<!-- <label for="phone">Phone</label>
    <input type="number" id="phone" name="Phone" >
 <label for="email">Email</label>
    <input type="email" id="email" name="email">
<label for="att">Attendence</label>
    <input type="number" id="att" name="att" placeholder="Your attendence ..">
<label for="supply">Supply</label>
    <input type="text" id="supply" name="supply" placeholder="Your supply count..">
<label for="Suspension">Suspension</label>-->
 
<label for="suspension">Do you have any suspension?</label> <table>  <tr>
      <td colspan=0> </td>
      <td><input type="radio" name="suspension" id="radio1" value="yes" />
        Yes &nbsp;&nbsp;        <input type="radio" name="suspension" id="radio1" value="no" />
        No </td>
  
    </tr></table>
    <label for="supply">Do you have any supply?</label> <table>  <tr>
      <td colspan=0> </td>
      <td><input type="radio" name="supply" id="radio2" value="yes" />
        Yes &nbsp;&nbsp;        <input type="radio" name="supply" id="radio2" value="no" />
        No </td>
  
    </tr></table>


    <label for="attendence">Attendence </label>
    <input type="Number" id="attendence" name="att" placeholder="">
<label for="att"></label><BR>


<label for="suportername">Supporter Name</label>
    <input type="text" id="sname" name="sname" placeholder="Your supporter name..">
<label for="sadno">Supporter Adno</label>
    <input type="number" id="sadno" name="sadno">

    
  
  <center>  <input type="submit" value="submit" name="submit"></center>
  </form>
</div>
<?php
}
} 

?>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js" ></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/3.3.1/jquery-ui.min.js" ></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script>
  jQuery.validator.addMethod("lettersonly", function(value, element) {
  return this.optional(element) || /^[a-z]+$/i.test(value);
}, "Letters only please");
    jQuery.validator.addMethod("noSpace", function(value, element) {
    return value == '' || value.trim().length != 0;
}, "No space please and don't leave it empty");
jQuery.validator.addMethod("customEmail", function(value, element) {
  return this.optional( element ) || /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test( value );
}, "Please enter valid email address!");



jQuery.validator.addMethod("passstrength", function(value, element) {
    return this.optional(element) || /([0-9])/ && /([a-zA-Z])/ && /([~,!,@,#,$,%,^,&,*,-,_,+,=,?,>,<])/.test(value);});


jQuery.validator.addMethod("alphabetsnspace", function(value, element) {
    return this.optional(element) || /^[a-zA-Z ]*$/.test(value);},"Invalid!");

jQuery.validator.addMethod("validDate", function(value, element) {
        return this.optional(element) || moment(value,"DD/MM/YYYY").isValid();
    }, "Please enter a valid date in the format DD/MM/YYYY");


jQuery.validator.addMethod("phoneno", function(phone_number, element) {
          phone_number = phone_number.replace(/\s+/g, "");
          return this.optional(element) || phone_number.length > 9 && 
          phone_number.match(/^((\+[6-9]{1,4}[ \-]*)|(\([0-9]{2,3}\)[ \-]*)|([0-9]{2,4})[ \-]*)*?[0-9]{3,4}?[ \-]*[0-9]{3,4}?$/);
      }, "<br />Please specify phone number");


$.validator.addMethod( "alphanumeric", function( value, element ) {
return this.optional( element ) || /^\w+$/i.test( value );
}, "Letters, and underscores only please" );

var $registrationForm = $('#myform');
if($registrationForm.length){
  $registrationForm.validate({
      rules:{
          //username is the name of the textbox
           class:{
            required: true,
            
        },
         suspension:{
            required: true,
            
        },
    
    supply:{
             required: true,
      },
          
      sname:{
             required: true,
      },   
       sadno:{
             required: true,
      },
      
 

      

      },
      messages:{
          
        /* lname:{
            required: 'Please enter the lname!'
         },*/  class:{
            required: 'Enter your class',
        
          },
          suspension:{
            required: 'Enter yes or no',
        
          },
       supply:{
            required: 'Enter yes or no'
             },
      
        time:{
            required: 'Enter a valid date'
             },
      
       sname:{
            required: 'Enter supporter name'
             },
       sadno:{
            required: 'Enter supporter admission number'
             },  
          
      },

  });
}
  </script>
</body>
</html>
<?php
  if(isset($_POST['submit']))
   {
     $ad=$_POST['adno'];
     $cl=$_POST['class'];
 
     $sus=$_POST['suspension'];
 
 $sup=$_POST['supply'];
 $att=$_POST['att'];
  $sname=$_POST['sname'];
  $sadno=$_POST['sadno'];

    
 
  
    $sq="insert eregister (userid,adno,class,sus,sup,att,sname,sadno,estatus,vstatus,vote)values('$id','$ad','$cl',
    '$sus','$sup','$att','$sname','$sadno','0','0','0')";
if(mysqli_query($co,$sq))
{

      echo "<script> alert('Success');
        </script>";

   

}}

?>  