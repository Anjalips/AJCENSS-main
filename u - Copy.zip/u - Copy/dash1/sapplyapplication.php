<?php
include 'co.php';
include 'sheader.php';


$lid=$_SESSION['userid'];
if(isset($lid))
{
	$em=$_GET['id'];	
	
$sql="insert into applyapp (userid,appid,aplistatus,apprvstatus)values('$lid','$em',1,0)";
if(mysqli_query($co,$sql))
{

echo "<script>alert('Applied');
      window.location='viewapplication.php'</script>";

}}
else
header("location:login.php");
?>
