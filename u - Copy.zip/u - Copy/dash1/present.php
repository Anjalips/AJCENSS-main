<?php
include "co.php";
$b=$_GET['id'];

    $sqd=mysqli_query($co,"select * from applyactivity where userid='$b' and apprstatus='1' and atstatus='1'");
   $rr=mysqli_fetch_assoc($sqd);
  {
$ete=$rr['atte'];
   $t=$ete+70;

}
$sql=mysqli_query($co,"update  applyactivity set atte='$t' where userid='$b' and apprstatus='1' ");

$sqll=mysqli_query($co,"update  applyapp set ts='1' where userid='$b' and apprvstatus='1' ");
if ( $sql && $sqll  ){
echo "<script>alert('Present');
      window.location='attendence.php';</script>";
}
else {
	echo "<script>alert('Error');</script>";
}
?>
