<?php 
include 'co.php'; 
include 'vsheader.php';


$login=$_SESSION['login'];
$type=$_SESSION['type'];
$id=$_SESSION['userid'];
if($login)
{
  ?>
<!DOCTYPE HTML>
<html>
<head>
    <style type="text/css">
    th{
      width: 150px;
      height: 50px;
      background-color:#4caf50;
      color: white;

    }
    td{
      width: 150px;
      height: 30px;
      

    }
    th,td{
      text-align: left;
      padding: 12px;
    }

  
    
    
  </style>
<title>Add Notices</title><meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Shoppy Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<!--js-->
<script src="js/jquery-2.1.1.min.js"></script> 
<!--icons-css-->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Carrois+Gothic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Work+Sans:400,500,600' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" 
integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" 
integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" 
crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" 
integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
 crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
 integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
 crossorigin="anonymous"></script>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

  <div class="blank">

   
<form name="myform" method="post" class="form-container" id="myform">

<h3 style="text-align: center;">Activity attendence</h3><br/>
   <div class="form-group">
       <div class="form-group">
     <table border="0"  width="95%" align="center" >

 <tr><th>Admission number</th>
   
    <th>Name</th>
<th>Activityname</th>
  <th>Attendence</th>
  <th>Absent</th>
    
  </tr>

<?php

// $res=mysqli_query($co,"select * from registers where saprstatus='1' ");
// while($row=mysqli_fetch_assoc($res))
// {
  
  // $lid=$row['userid'] ;
  // $sq=mysqli_query($co,"select * from registers where userid='$lid' ");
  // $r=mysqli_fetch_array($sq,MYSQLI_ASSOC);
  // $em=$row['adno'];

  //   $ap=$row['name'];
  //   $uid=$row['userid'];
  
    // $re=mysqli_query($co,"select * from applyapp where apprvst''atus='1' ");
//while($ro=mysqli_fetch_assoc($re))

//  while( $ro=mysqli_fetch_assoc($re));
// {
  
  // $lid=$row['userid'] ;
  // $sq=mysqli_query($co,"select * from registers where userid='$lid' ");
  // $r=mysqli_fetch_array($sq,MYSQLI_ASSOC);
 //  $emm=$ro['appid'];

 // $sq=mysqli_query($co,"select * from application where appid='$emm' ");
 // while( $r=mysqli_fetch_assoc($sq));
 // {
 //  $mm=$r['applicationname'];
    
$res=mysqli_query($co,"select * from registers,applyactivity where registers.actiapprove='1' and applyactivity.apprstatus='1' and registers.userid=applyactivity.userid ");
 while($row=mysqli_fetch_assoc($res))
{
  $ap=$row['name'];
  $uid=$row['userid'];
  $emm=$row['activityid'];
$em=$row['adno'];
$et=$row['atte'];
$st=$row['atstatus'];
$pq=$row['apprstatus'];
    $sq=mysqli_query($co,"select * from activity where activityid='$emm' ");
   $r=mysqli_fetch_assoc($sq);
  {
   $mm=$r['activityname'];
   $mh=$r['hourwork'];
   $t=$et+$mh;
   $mt=$et-$mh;
 $rest=mysqli_query($co,"select * from applyactivity where userid='$uid' and apprstatus='1'  ");
 while($row=mysqli_fetch_assoc($rest))
{
  

  

$ett=$row['atte'];
}
?>


<tr>
<td> 
   <?php 
        echo $em;
    ?>

  </td>

<td>
<?php
echo $ap;
?>
</td>
<td>
<?php
echo $mm;
?>
</td>
<td>
<?php

    if($st==1  && $pq==1 ){
       echo "present";
   }

   else { ?>
   
<button  ><a href="actipresent.php?id=<?php echo $uid ?> ">Attendence</a></button>
 </td><?php } 
?>
<td>

<?php
    if($st==0  && $pq==1){
       echo "absent";
   }

   else { ?>
<button><a href="actiabsent.php?id=<?php echo $uid; ?> && id1=<?php echo $mt; ?>">Absent</a></button>
</td><?php } 
?>

</tr>
<?php
}}



?>


</body>

</html>
    </div>


</div>
</div>



   <?php
 
}
else
header("location:login.php");
?>          
                      
        
