<?php
include 'co.php';
include 'sheader.php';
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="css/style1.css">


<script>
  /*
function validateform()
{
var nam=/^[a-zA-Z\s]+$/;
var c=document.myform.name.value;
 if(c==null || c=="")
     {
     alert("name can't be empty");
     return false;
     }
    if (!nam.test(document.myform.name.value)) {
    alert('Please provide a valid name');
    name.focus;
    return false;
 } 
if( document.myform.adno.value == "" ||
           isNaN( document.myform.adno.value) ||
           document.myform.adno.value<1000 )
   {
     alert( "Please provide a Admission No in the format 123." );
     document.myform.adno.focus() ;
     return false;
   }
var b=document.forms["myform"]["class"].value;
if(b=="")
{
alert("Please Fill which deparment you are ?");
return false;
}
if( document.myform.year.value == "" ||
           isNaN( document.myform.year.value) ||
           document.myform.year.value != 2 )
   {
     alert( "eligible if you are asecond year student" );
     document.myform.year.focus() ;
     return false;
   }
var c=document.forms["myform"]["address"].value;
if(c=="")
{
alert("Please Fill address field");
return false;
}



var emailid = /^([a-z0-9A-Z_\.\-])+\@(([a-zA-Z\-])+\.)+([a-zA-Z]{2,4})+$/;
var c=document.myform.emailid.value;
 if(c==null || c=="")
     {
     alert("email can't be empty");
     return false;
     }
    if (!emailid.test(document.myform.emailid.value)) {
    alert('Please provide a valid email id');
    emailid.focus;
    return false;
 } 
var c=document.forms["myform"]["experience"].value;
if(c=="")
{
alert("Please Fill  experience");
return false;
}
 if( document.myform.phone.value == "" ||
           isNaN( document.myform.phone.value) ||
           document.myform.phone.value.length != 10 )
   {
     alert( "Please provide a Mobile No in the format 123.upto 10 digit" );
     document.myform.phone.focus() ;
     return false;
   }
    if((document.myform.phone.value.charAt(0)!=9) && 
    (document.myform.phone.value.charAt(0)!=8) &&
(document.myform.phone.value.charAt(0)!=7) && 
    (document.myform.phone.value.charAt(0)!=6))
   {
alert( "Please provide a valid 10 digit mobile no. start with '9' or '8' or'7' or '6'" );
     document.myform.phone.focus() ;
     return false;
   }
   
   var x=document.forms["myform"]["dob"].value;
if(x=="")
{
alert("Please Fill Date of birth");
document.getElementById("dob").focus();
return false;
}
var GivenDate =document.forms["myform"]["dob"].value;
var CurrentDate = new Date();
GivenDate = new Date(GivenDate);

if(GivenDate > CurrentDate){
    alert('Given date is greater than the current date.');
  document.getElementById("dob").focus();
  return false;
}

   var c=document.forms["myform"]["gender"].value;
if(c=="")
{
alert("Please Fill student gender");
return false;
}

 var c=document.forms["myform"]["bloodgroup"].value;
if(c=="-1")
{
alert("Please Fill your blood group");
return false;
}

    if(myform.password.value != "" && myform.password.value == myform.cpassword.value) {
      if(myform.password.value.length < 6) {
        alert("Error: Password must contain at least six characters!");
        myform.password.focus();
        return false;
      }
      
      re = /[0-9]/;
      if(!re.test(myform.password.value)) {
        alert("Error: password must contain at least one number (0-9)!");
        myform.password.focus();
        return false;
      }
      re = /[a-z]/;
      if(!re.test(myform.password.value)) {
        alert("Error: password must contain at least one lowercase letter (a-z)!");
        myform.password.focus();
        return false;
      }
      re = /[A-Z]/;
      if(!re.test(myform.password.value)) {
        alert("Error: password must contain at least one uppercase letter (A-Z)!");
        myform.password.focus();
        return false;
      }
    } 
  else {
      alert("Error: Please check that you've entered and confirmed your password!");
      myform.password.focus();
      return false;
    }

    return true;
 
}
</script>
*/

<link rel="stylesheet" type="text/css" href="style1.css">

<style>

#bg {
  position: fixed;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background: url("an.jpg") no-repeat center center fixed;
  background-size: cover;

}




</style>
</head>
<body class="barber_version"  >

<div id="bg"></div>
<form name="myform" action="elction.php" onsubmit="return validateform()" method="post" enctype="multipart/form-data">


  <table  border="0" width="100%"  cellpadding="10">
    <center><h1><u> ELECTION  </u></h1></center>
    <tr>
      <td> Admission Number :<input type="number" name="adno" id="t2" /></td>
    </tr>
      <td> Candidate Name : <input type="text" name="name" id="t1"   onChange="return validateform1()">
                        <script>
        function validateform1()
          {
var x=document.forms["myform"]["name"].value;
if(x=="")
{
alert("Please Fill name");
document.getElementById("myform").focus();
return false;
}
var x=new RegExp("^[a-zA-z ]*$");
if(!x.test(document.myform.name.value))
{
  alert("Enter name with characters only");
  myform.name.focus();
  document.getElementById("name").value="";
  return false;
}
var x=document.forms["myform"]["name"].value;
if(x.length<2 || x.length>30)
{
alert("Please enter name with more than 2 letters and less than 30 letters");
document.getElementById("name").focus();
document.getElementById("name").value="";
return false;
}
return true;
      }
          
          </script>
                        </td>
   

      
      
    </tr>
  <tr>
     
      <td> Department Name :<input type="text" name="class" id="class" onChange="return validateform2()">
                        <script>
        function validateform2()
          {
var x=document.forms["myform"]["class"].value;
if(x=="")
{
alert("Please Fill departmet");
document.getElementById("myform").focus();
return false;
}
var x=new RegExp("^[a-zA-z ]*$");
if(!x.test(document.myform.class.value))
{
  alert("Enter department with characters only");
  myform.class.focus();
  document.getElementById("class").value="";
  return false;
}
var x=document.forms["myform"]["class"].value;
if(x.length<2 || x.length>50)
{
alert("Please enter deparment with more than 2 letters and less than 50 letters");
document.getElementById("class").focus();
document.getElementById("class").value="";
return false;
}
return true;
      }
          
          </script>
          </td>
    
    <td><label>&nbsp &nbsp &nbsp &nbsp Year Of Study:</label>
      <input type="number" name="year" id="t9"  ></td>
    </tr>
  <tr>
    <td> <label>Backlog :</label>
      <input type="text" name="backlog" id="backlog" onChange="return validateform11()">
                        <script>
        function validateform11()
          {
var x=document.forms["myform"]["backlog"].value;
if(x=="")
{
alert("Please Fill address");
document.getElementById("backlog").focus();
return false;
}
      }
          
          </script></td>
    
  <td>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp Email Id :<input type="text" name="attendence" id="attendence"  onChange="return valiadteform3()">
                    
                    <script>
                      function valiadteform3()
        {

var c=document.myform.attendence.value;
 if(c==null || c=="")
     {
     alert("attendence can't be empty");
     return false;
     }
  
  }              
     </script>
</td>
      
    </tr>
    <tr>
      <td colspan=0>Do you have any suspension</td>
      <td><input type="text" name="suspension" id="suspension" value="yes" />
     
      </td>
  
    </tr>
  <tr>
     
     
      <td>Mark :<input type="number" name="mark" id="t13"  /></td>
    
     <td>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbspDob:<input type="date" name="dob" id="dob" onChange="return validateform13()" >
                             <script>
        function validateform13()
        {
var x=document.forms["myform"]["dob"].value;
if(x=="")
{
alert("Please Fill Date of birth");
document.getElementById("dob").focus();
return false;
}
var GivenDate =document.forms["myform"]["dob"].value;
var CurrentDate = new Date();
GivenDate = new Date(GivenDate);

if(GivenDate > CurrentDate){
    alert('Given date is greater than the current date.');
  document.getElementById("dob").focus();
  return false;


}
return true;
        }       
        </script></td>
    </tr>
  <tr>
      <td>Gender</td>
      <td><input type="radio" name="gender" id="radio3" value="Male" />
        Male
        <input type="radio" name="gender" id="radio4" value="female" />
        Female </td>
    </tr>
<tr>
     <td>Bloodgroup &nbsp &nbsp &nbsp </td>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
    <td style="width=20px" height="20px"><select name="bloodgroup" id="i19"  >
    <option value=-1 >select blood group</option>
    <option value="a+">A+ve</option>
    <option value="a-">A-ve</option>
    <option value="b+">B+ve</option>
    <option value="b-">B-ve</option>
    <option value="o+">O+ve</option>
    <option value="o-">O-ve</option>
    <option value="ab+">AB+ve</option>
    <option value="ab-">AB-ve</option>
    </select></td>
 <tr>
            <td>   Photo: <input type="file" id="file" name="file" class="form-control" placeholder="upload image"></td>
          
          
            <td>   Idcard: <input type="file" id="fil" name="fil" class="form-control" placeholder="upload idcard"></td>
          </tr>  
<tr>
      
      <td>Password :<input type="password" name="password" id="password" / >
                          </textarea></td>
   
      
      <td>Confirm Password :<input type="password" name="cpassword" id="t16" /></textarea></td>
    </tr>
  
   
  </table>
 <center><input type="submit" value="submit" name="submit"  />
</fieldset>
</form>
<?php
  if(isset($_POST['submit']))
   {
     $name=$_POST['name'];
     $adno=$_POST['adno'];
 $c=$_POST['class'];
     $d=$_POST['year'];
 $e=$_POST['address'];
     $f=$_POST['experience'];
 $g=$_POST['emailid'];
     $h=$_POST['phone'];
 $t=$_POST['gender'];
 $z=$_POST['bloodgroup'];
 $j=$_POST['dob'];
  $s=$_POST['password'];
 $dir='photo/';
$target_file=$dir.basename($_FILES['file']['name']);
move_uploaded_file($_FILES['file']['tmp_name'], $target_file);
 $di='photo/';
$target_fil=$di.basename($_FILES['fil']['name']);
move_uploaded_file($_FILES['fil']['tmp_name'], $target_fil);


    
     $ss=mysqli_query($co,"select * from login where emailid='$g'");
  $i=mysqli_num_rows($ss);
  if($i>0)
  {
         echo "
        <script>
        alert('already exists id');
        </script>";
  }
  else
  {
    $ps=md5($s);
    $sq="insert into login(emailid,password,usertype,approvedstatus)values('$g','$ps','3','0')";
if(mysqli_query($co,$sq))
{
  $sql=mysqli_query($co,"select userid from login where emailid='$g' ");
  $re=mysqli_fetch_array($sql,MYSQLI_ASSOC);
  $lid=$re['userid'];
  //echo "<script>alert('$lid');</script>";
    $pq="insert into register(adno,userid,name,class,year,address,experience,phone,gender,bloodgroup,dob,img,idcard,verifystatus)values('$adno','$lid','$name','$c','$d','$e','$f','$h','$t','$z','$j','$target_file','$target_fil','0')";
  if(mysqli_query($co,$pq))
      echo "<script> alert('Success');
           window.location='/u/index.html'</script>";
}
}
   }
?>
           