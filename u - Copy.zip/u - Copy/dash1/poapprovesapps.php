
<?php
include "co.php";
$b=$_GET['id'];
$sql=mysqli_query($co,"update  applyapp set apprvstatus='1' where userid='$b'");
$sqll=mysqli_query($co,"update   registers set saprstatus='1' where userid='$b'");


if ( $sql && $sqll  ){
echo "<script>alert('Approved');
      window.location='poapprovestudents.php';</script>";
}
else {
	echo "<script>alert('Error');</script>";
}
?>
