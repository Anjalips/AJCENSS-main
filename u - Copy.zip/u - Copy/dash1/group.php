<?php 
include 'co.php'; 
include 'vsheader.php';

$login=$_SESSION['login'];
$type=$_SESSION['type'];
$id=$_SESSION['userid'];
if($login)
{
  ?>
<!DOCTYPE html>
<html>
 <head>
  <title>Webslesson Tutorial | Bootstrap Multi Select Dropdown with Checkboxes using Jquery in PHP</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css" />
 </head>
 <body>
  <br /><br />
  <div class="container" style="width:600px;">
  

   
<form name="myform" method="post" class="form-container" id="myform">
          
          <br>
          <h2 ><center>Grop Selection</center> </h2><br>
            <div class="form-group">
            <label>Group *</label>
            <input id="group" name="group" class="form-control" type="textarea" data-validation="required" rows="10" cols="20" onchange="return validateform1()" required="">
             <script>
          function validateform1()
          {
var x=document.forms["myform"]["group"].value;
if(x=="")
{
alert("Please Fill group name");
document.getElementById("group").focus();
return false;
}
var x=new RegExp("^[a-zA-z0-9 ]*$");
if(!x.test(document.myform.group.value))
{
  alert("Enter group with characters and numbers only");
  myform.group.focus();
  document.getElementById("group").value="";
  return false;
}

return true;
      }
   </script>
   <div class="form-group">
    <label>Group leaders *</label>
            <input id="groupl" name="groupl" class="form-control" type="textarea" data-validation="required" rows="10" cols="10" required="" ">


</div>

    <div class="form-group">
     <label>Group members</label>
     
     <?php
   
          
  // $sq=mysqli_query($co,"select * from register  ");
  // $r=mysqli_fetch_array($sq,MYSQLI_ASSOC);
  // $em=$r['name'];

           
          
  $sq=mysqli_query($co,"select * from applyapp where appid='1' && apprvstatus='1' ");
  $rr=mysqli_fetch_array($sq,MYSQLI_ASSOC);
   $em=$rr['userid'];
   $s=mysqli_query($co,"select * from registers  where saprstatus='1'");

  
    ?>

   
    <select id="framework" name="framework[]" class="form-control" multiple class="form-control" required="">
                       <?php

while($row=mysqli_fetch_array($s))
                      {

                        ?>
                   <option value="<?php echo $row['name'];?>"><?php echo $row['name'];?></option>
           
                      <?php
                      }
   ?>
    </div>
    <br>
    <br>
    

    <div class="form-group">
     <input type="submit" class="btn btn-success center" name="submit" value="Submit" />
    </div>
   </form>
   <br />
  </div>
 </body>
</html>

<script>
$(document).ready(function(){
 $('#framework').multiselect({
  nonSelectedText: 'Select Group members',
  enableFiltering: true,
  enableCaseInsensitiveFiltering: true,
  buttonWidth:'400px'
 });
 
 
  });

 
 

</script>
  
</body>
  </html>


<?php
  if(isset($_POST['submit']))
   {
     $sug=$_POST['group'];
     $su=$_POST['groupl'];

  
    if(isset($_POST['framework'])){
    $framework = '';
 foreach($_POST["framework"] as $row)
 {
  $framework .= $row . ', ';
 }
 $framework = substr($framework, 0, -2);
 $query = "INSERT INTO groupp(groupname,gnum,leader,gstatus) VALUES('".$sug."','".$framework."','".$su."','1')";
 if(mysqli_query($co, $query))
 

{
  
      echo "<script> alert('Success');
           window.location='group.php'</script>";
}
}
 } 
?>
 <?php
}
else
header("location:login.php");
?>  