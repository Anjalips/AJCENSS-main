



<?php 
include 'co.php'; 
include 'sheader.php';


$login=$_SESSION['login'];
$type=$_SESSION['type'];
$id=$_SESSION['userid'];
if($login)
{
  $res=mysqli_query($co,"select  * from registers where  userid='$id' ");
 while($row=mysqli_fetch_assoc($res))
{  
$a=$row['name'];
$b=$row['adno'];
$c=$row['year'];
$d=$row['class'];
$s=$row['phone'];
$m=$row['dob'];
$n=$row['address'];
  ?>
<!DOCTYPE html>
<html>
<style>
body {
  font-family: Arial;
}

input[type=text], select {
  width: 100%;
  padding: 10px 15px;
  margin: 8px 0;
  display: block;
  border: 1px solid #ccc;
  border-radius: 3px;
  box-sizing:border-box;
}

input[type=submit] {
  width: 30%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 18px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

div.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 30px;
}
</style>
<body>
<form name="myform" action="profile.php"  method="post" >
<h3>Profile</h3><input type="text" id="img"  name="img" >
<img src="<?php echo $row['img'];?>" width=20%
  height=20% ">

<div class="container">


    <label for="fname"> Name</label> 
    <input type="text" id="name" name="name" value="<?php
echo "$a"?> "> 


    
    <label for="adno">Admission Number</label> 
    <input type="text" id="adno" name="adno" value="<?php
echo "$b"?> "> 
 <label for="adno">Date of birth</label> 
    <input type="text" id="dob" name="dob" value="<?php
echo "$m"?> "> 
<label for="adno">Address</label> 
    <input type="text" id="address" name="address" value="<?php
echo "$n"?> ">
<label for="dept">Department</label> <input type="text" id="dept" name="dept"value="<?php
echo "$d"?> "> <br>
 
    <label for="phone">Phone Number</label>
      <input type="text" id="phone" name="phone" value="<?php
echo "$s"?> "> <br>
    <label for="emailid">Emailid</label><?php

$ress=mysqli_query($co,"select  *  from login where  userid='$id'");
 while($roww=mysqli_fetch_assoc($ress))
{  
$e=$roww['emailid'];
}}
}
?>
    <input type="email" id="email" name="email" value="<?php
echo "$e"?> "> 
    <br>


    
  
  <center>  <input type="submit" name="submit" value="submit" /> </center>
  </form>
</div>


</body>
</html>

<?php
    if (isset($_POST['submit'])) {
 $name = $_POST['name'];
 $adno = $_POST['adno'];
 $dob = $_POST['dob'];
 $dept = $_POST['dept'];
 $address = $_POST['address'];
 $phone = $_POST['phone'];


 $update_profile = ("UPDATE registers SET name = '$name', adno = '$adno', dob = '$age', address = '$address', dept = '$dept', phone = '$phone'");
     if ($update_profile) {
    echo "<script>alert('Updated');
      window.location='profile.php';</script>";
}
else {
  echo "<script>alert('Error');</script>";
}
}

?>