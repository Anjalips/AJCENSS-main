<?php
include "co.php";
$em=$_GET['id'];
$sql2="update activity set astatus='1' where activityid='$em'";


if(mysqli_query($co,$sql2))
{
echo "<script>alert('Approved');
      window.location='approveactivity.php'</script>";
}
?>