 <?php 
include 'co.php'; 
include 'aheader.php';



session_start();
$login=$_SESSION['login'];
$type=$_SESSION['type'];

if($login)
{
  ?>
  <?php echo "<font size=5 color=blue>Welcome $type ";?>
 
 


	<body id="home" background="bb.jpg">
    <div class="logo-sidebar">
      
<?php
$select="SELECT * FROM `faq`";
$res=mysqli_query($co,$select);
?>

<?php
while($row=mysqli_fetch_array($res))
{

?>

<h2><?php echo $row['faqid'];?>

<?php echo $row['fquestions'];?></h2>


<h4>&nbsp &nbsp &nbsp &nbsp &nbsp<?php echo $row['fanswers'];?></h4>
<?php
}
?>


      </center>
</font>
</body>
</html>
else
header("location:login.php");
?>