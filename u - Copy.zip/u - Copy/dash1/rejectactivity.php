<?php
include "co.php";
$b=$_GET['id'];

$sql=mysqli_query($co,"update  activity  set astatus='0' where activityid='$b'");


if ( $sql  ){
echo "<script>alert('Removed');
      window.location='approveactivity.php';</script>";
}
else {
	echo "<script>alert('Error');</script>";
}
?>