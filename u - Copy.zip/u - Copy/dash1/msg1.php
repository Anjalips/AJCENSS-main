<?php
include 'co.php';
if(isset($_POST['recover']))
{
	
		$emailid=$_POST['emailid'];
	//unset($_COOKIE["user"]);
	//unset($_COOKIE["regid"]);
	
	
	$sql="SELECT * FROM login WHERE emailid='$emailid'";
	$result=mysqli_query($co,$sql);
	$row=mysqli_fetch_assoc($result);
	$a=$row['emailid'];
	
	if($a==$emailid)
	{
	$e=$a;
		$m=rand();
		$m1="Your Password Is".$m;
	$p="password:".$row['password'];
	 $sql4="update login set password='".$m."' where emailid='".$a."'";
            if(mysqli_query($co,$sql4)){
                echo "<script>";
                echo "alert('Your Password has been sent to your email id')";
                echo"</script>"; 
            }

	//echo $p;
	echo mail("$e","Recover","$m1");
	//header("location:login.php?message=Authentication Success Please check your mail");
	}
	//else
		// echo "hiii";
	//header("location:signin.php?message=Please provide valid informations");
	}
	?>