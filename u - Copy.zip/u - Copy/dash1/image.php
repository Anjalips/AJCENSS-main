
   <?php
include ('co.php');
include ('vsheader.php');

 ?>

 <!DOCTYPE html>
<html>
<head>
<script type="text/javascript">

  function validateform()
{
  var c=document.forms["myform"]["file"].value;
 if(c==null || c=="")
     {
     alert("photo can't be empty");
     return false;
     }
     var c=document.forms["myform"]["fil"].value;
 if(c==null || c=="")
     {
     alert("image can't be empty");
     return false;
     } return true;
 
}
</script>
  <title>Gallery</title>
  <style>
  .ss
  {
	  margin-top:10px;
	  margin-left:250px;
  }
  
  </style>
   </head> 
<body>
 <form action="#" method="POST" onsubmit="return validateform()" enctype="multipart/form-data" id="myform">
 <h3><center>Add Images</center></h3>
<div class="ss">
  <table width="80%" >



<tr>
<td>Activity Name *</td>
<td><center><?php
    $select="select activityname from activity where astatus=1";
$res=mysqli_query($co,$select);



     ?><tr><td>
    <select  class="form-control" type="select" id="activityname" name="activityname" placeholder="select"> <option></option>
                       <?php
while($row=mysqli_fetch_array($res))
{
$p=$_POST['activityname'];
?>
<option value="<?php echo $row['activityname'];?>"><?php echo $row['activityname'];?></option>
           
<?php
}
?> </select></td></select></center></td>
 
            <tr>
            <td>   Image: <input type="file" id="file" name="file" class="form-control" placeholder="upload image" onchange="validateImage1()"></td>
          </tr>
        </table><br><br>
			  
                          
             
                
				
				
   
  
 <center><input type="submit" value="submit" name="submit"  /></center>
				
			</div> 	
             </form> 
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js" ></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/3.3.1/jquery-ui.min.js" ></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script>
  jQuery.validator.addMethod("lettersonly", function(value, element) {
  return this.optional(element) || /^[a-z]+$/i.test(value);
}, "Letters only please");
  jQuery.validator.addMethod("validDate", function(value, element) {
        return this.optional(element) || moment(value,"DD/MM/YYYY").isValid();
    }, "Please enter a valid date in the format DD/MM/YYYY");
   








var $registrationForm = $('#myform');
if($registrationForm.length){
  $registrationForm.validate({
      rules:{
          //username is the name of the textbox
          activityname: {
              required: true,
              //alphanumeric is the custom method, we defined in the above
            
          },
       
        file: {
              required: true,
          
           
          },  
         
          
      },
      messages:{
          activityname: {
              //error message for the required field
              required: 'choose activity',
            
          },
                 file: {
              //error message for the required field
              required: 'choose image',
              
            
          },
       
       

      },

  });
}
  </script>

</body>
</html>


      <?php
    if(isset($_POST['submit']))
    {
       
     
      $dir='photo/';
$target_file=$dir.basename($_FILES['file']['name']);
move_uploaded_file($_FILES['file']['tmp_name'], $target_file);



      
      $sql="INSERT INTO image ( activityname,image) VALUES ('$p','$target_file' )";
      $ch=mysqli_query($co,$sql);
     if($ch)

{
  
  ?>
   <script>

 alert("Added Successfully");
// window.location="login.php";

</script>

  <?php

}
else
{
  echo"error:".$sql."<br>".mysqli_error($co);
}
}
?>

<script type="text/javascript">
function validateImage1() {
    var formData = new FormData();
 
    var file = document.getElementById("file").files[0];
 
    formData.append("Filedata", file);
    var t = file.type.split('/').pop().toLowerCase();
    if (t != "jpeg" && t != "jpg" && t != "png" ) {
        alert('Please select a valid image file jpeg or jpg or png');
        document.getElementById("file").value = '';
        return false;
    }
    if (file.size > 1024000) {
        alert('Max Upload size is 1MB only');
        document.getElementById("file").value = '';
        return false;
    }
    
    return true;
}
</script>
