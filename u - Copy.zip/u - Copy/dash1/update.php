<?php
include "co.php";
$b=$_GET['id'];
 
     $name=$_POST['id2'];
   
    
$sqll=mysqli_query($co,"update registers set name='$name' where userid='$b'");
if (  $sqll ){
echo "<script>alert('Approved');
      window.location='studenthome.php';</script>";
}
else {
  echo "<script>alert('Error');</script>";
}
}

?>