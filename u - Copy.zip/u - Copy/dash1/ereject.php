
<?php
include "co.php";
$em=$_GET['id'];
$sql2="update eregister set estatus='0' where eid='$em'";
if(mysqli_query($co,$sql2))
{
echo "<script>alert('Rejected');
      window.location='eregisterapprove.php'</script>";
}

	?>