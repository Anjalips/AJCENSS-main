<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
include 'co.php';

session_start();
$login=$_SESSION['login'];
$type=$_SESSION['type'];

if($login)
{
  ?>
<!DOCTYPE HTML>
<html>
<head>

<title>Add Notices</title>
<script>

function validateform()
{
var nam=/^[a-zA-Z\s]+$/;
var c=document.myform.matter.value;
 if(c==null || c=="")
     {
     alert("notice can't be empty");
     return false;
     }
    if (!nam.test(document.myform.matter.value)) {
    alert('Please provide a valid notice');
    matter.focus;
    return false;
 } 
 var x=document.forms["myform"]["date"].value;
if(x=="")
{
alert("Please Fill Date ");
document.getElementById("dob").focus();
return false;
}
var GivenDate =document.forms["myform"]["date"].value;
var CurrentDate = new Date();
GivenDate = new Date(GivenDate);

if(GivenDate < CurrentDate){
    alert('Given date is greater than the current date.');
  document.getElementById("date").focus();
  return false;
}

var c=document.forms["myform"]["time"].value;
if(c=="")
{
alert("Please Fill time field");
return false;
}

    

    return true;
 
}
</script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Shoppy Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<!--js-->
<script src="js/jquery-2.1.1.min.js"></script> 
<!--icons-css-->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Carrois+Gothic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Work+Sans:400,500,600' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" 
integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" 
integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" 
crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" 
integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
 crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
 integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
 crossorigin="anonymous"></script>

 <div class="blank">
</head>
 



<body>  
<div class="page-container">  
   <div class="left-content">
     <div class="mother-grid-inner">
            <!--header start here-->
        <div class="header-main">
          <div class="header-left">
              <div class="logo-name">
                   <a href="index.html"> <h1>AJCE NSS</h1> 
                  <!--<img id="logo" src="" alt="Logo"/>--> 
                  </a>                
              </div>                                            
             </div>
             <div class="header-right">
              
              <!--notification menu end -->
             <div class="profile_details">    
                <ul>
                  <li class="dropdown profile_details_drop">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                      <div class="profile_img"> 
                        <span class="prfil-img"><img src="images/p1.png" alt=""> </span> 
                        <div class="user-name">
                          <span><h4> <?php echo " $type ";?></h4></span>
                        </div>
                        <i class="fa fa-angle-down lnr"></i>
                        <i class="fa fa-angle-up lnr"></i>
                        <div class="clearfix"></div>  
                      </div>  
                    </a>
                    <ul class="dropdown-menu drp-mnu">
                      
                      <!--<li> <a href="#"><i class="fa fa-user"></i> Profile</a> </li> -->
                      <li> <a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a> </li>
                    </ul>
                  </li>
                </ul>
              </div>          
            </div>
             <div class="clearfix"> </div>  
        </div>
        
         
          
          


 <h2><center></center></h2>
<div class="inner-block1"></div>
<div class="container-fluid ">
<div class="row">
  
    <div class="col-md-4 col-sm-4 col-xs-12 "></div>
    <div class="col-md-4 col-sm-4 col-xs-12  box">
      
        <form name="myform" method="post" class="form-container" id="myform" onsubmit="return validateform()">
          
          
          <h2 ><center>Add Notice</center> </h2><br>
            <div class="form-group">
            <label>Notice *</label>
            <input id="matter" name="matter" class="form-control" type="textarea" data-validation="required" rows="5" cols="5">
            <span id="error_notice" class="text-danger"></span>
          </div>
          
            <div class="form-group">
            <label>Date *</label>
            <input id="date" name="date" class="form-control" type="date" data-validation="required" rows="5" cols="5"onchange="return validateform3()">
           <script>
        function validateform3()
        {
var x=document.forms["myform"]["date"].value;
if(x=="")
{
alert("Please Fill Date ");
document.getElementById("date").focus();
return false;
}
var GivenDate =document.forms["myform"]["date"].value;
var CurrentDate = new Date();
GivenDate = new Date(GivenDate);

if(GivenDate < CurrentDate){
    alert('Given date is less than the current date.');
  document.getElementById("date").focus();
  document.getElementById("date").value="";
  return false;
}

return true;
        }       
        </script>
            <span id="error_notice" class="text-danger"></span>
          </div>
        
            <div class="form-group">
            <label>Time *</label>
            <input id="time" name="time" class="form-control" type="time" data-validation="required" rows="5" cols="5">
            <span id="error_notice" class="text-danger"></span>
          </div>
          <center><button id="submit" type="submit" name="submit" value="Add Notice" class="btn btn-success center">Add Notice</button></center>


      
        </form>

      </div>
      
      <div class="col-md-4 col-sm-4 col-xs-12"></div>
    </div >
  </div>
 

  </form>

</font>
 
 


<!--inner block end here-->
<!--pop-up-grid-->
                       <div id="popup">
                <div id="small-dialog" class="mfp-hide">
                    
                </div>
                </div><br><br><br><br>
                
<!--pop-up-grid-->
<!--copy rights start here-->
  
<!--COPY rights end here-->
</div>
</div>
<!--slider menu-->
      <div class="sidebar-menu">
        <div class="logo"> <a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> <a href="#"> <span id="logo" ></span> 
            <!--<img id="logo" src="" alt="Logo"/>--> 
        </a> </div>     
        <div class="menu">
          <ul id="menu" >
            <li id="menu-home" ><a href="/u/dash1/programofficerhome.php"><i class="fa fa-tachometer"></i><span>Home</span></a></li>
            <li><a href="#"><i class="fa fa-cogs"></i><span>Add</span><span class="fa fa-angle-right" style="float: right"></span></a>
              <ul>
                <li><a href="award.php">Award</a></li>
                <li><a href="notice.php">Notice</a></li>  
           <li><a href="faq.php">FAQ</a></li>  
          
      
      
              </ul>
        <li><a href="#"><i class="fa fa-cogs"></i><span>Approve</span><span class="fa fa-angle-right" style="float: right"></span></a>
              <ul>
                <li><a href="approve.php">New Request</a></li>
                <li><a href="approveapp.php">New Application</a></li> 
          <li><a href="approveactivity.php">New Activity</a></li>
                <li><a href="poapplystudents.php">Activity Participants List</a></li>  
           <li><a href="poapprovestudents.php">  Application Participants List</a></li>  
          
      
      
              </ul>
            </li>
           
              <li id="menu-comunicacao" ><a href="suggestion2.php"><i class="fa fa-book nav_icon"></i><span>View Suggestion</span></a>
  
            <li id="menu-comunicacao" ><a href="/nss%20-%20Copy/viewaward2.php"><i class="fa fa-book nav_icon"></i><span> View Gallery</span></a>
  
      
            
  
      
                
        
            <li id="menu-academico" ><a href="history.php""><i class="fa fa-file-text"></i><span>History</span></a>
             
          
      
            
           <li><a href="pchangepw.php"><i class="fa fa-cog"></i><span>Change Password</span></a>
               
            
      </ul>
        </div>
   </div>
  <div class="clearfix"> </div>
</div>
<!--slide bar menu end here-->
<script>
var toggle = true;
            
$(".sidebar-icon").click(function() {                
  if (toggle)
  {
    $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
    $("#menu span").css({"position":"absolute"});
  }
  else
  {
    $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
    setTimeout(function() {
      $("#menu span").css({"position":"relative"});
    }, 400);
  }               
                toggle = !toggle;
            });
</script>
<!--scrolling js-->
    <script src="js/jquery.nicescroll.js"></script>
    <script src="js/scripts.js"></script>
    <!--//scrolling js-->
<script src="js/bootstrap.js"> </script>
<!-- mother grid end here-->

<!--<div class="copyrights">
   <p>© 2019 volareairways. All Rights Reserved | Design by  <a href="http://volareairways.com/" target="_blank">volare Airways</a> </p>
</div>-->






var toggle = true;
            
$(".sidebar-icon").click(function() {                
  if (toggle)
  {
    $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
    $("#menu span").css({"position":"absolute"});
  }
  else
  {
    $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
    setTimeout(function() {
      $("#menu span").css({"position":"relative"});
    }, 400);
  }               
                toggle = !toggle;
            });
</script>
<!--scrolling js-->
   
    <!--//scrolling js-->

</form>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js" ></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/3.3.1/jquery-ui.min.js" ></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script>
  jQuery.validator.addMethod("lettersonly", function(value, element) {
  return this.optional(element) || /^[a-z]+$/i.test(value);
}, "Letters only please");
  jQuery.validator.addMethod("validDate", function(value, element) {
        return this.optional(element) || moment(value,"DD/MM/YYYY").isValid();
    }, "Please enter a valid date in the format DD/MM/YYYY");
   








var $registrationForm = $('#myform');
if($registrationForm.length){
  $registrationForm.validate({
      rules:{
          //username is the name of the textbox
          matter: {
              required: true,
              //alphanumeric is the custom method, we defined in the above
            
          },
       
        date: {
              required: true,
              validdate: true
              //alphanumeric is the custom method, we defined in the above
           
          },  
          time: {
              required: true,
              //alphanumeric is the custom method, we defined in the above
              
          },  
         
          
      },
      messages:{
          matter: {
              //error message for the required field
              required: 'Enter matter',
            
          },
                 date: {
              //error message for the required field
              required: 'choose date',
              validdate:'enter a valid date'
            
          },
       
         time: {
              //error message for the required field
              required: 'Enter valid time',
             
          }, 

      },

  });
}
  </script>

</body>
</html>

<?php
  if(isset($_POST['submit']))
   {
     $matter=$_POST['matter'];
     
 $date=$_POST['date'];
     $time=$_POST['time'];
 
  
    $sq="insert notice (date,time,matter)values('$date','$time','$matter')";
if(mysqli_query($co,$sq))
{
  
      echo "<script> alert('Success');
           window.location='notice.php'</script>";
}
}
   
?>
   <?php
}
else
header("location:login.php");
?>          