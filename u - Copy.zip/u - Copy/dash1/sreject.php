<?php
include "co.php";
$b=$_GET['id'];

$sqll=mysqli_query($co,"update   sacti set sstatus='0' where seid='$b'");
if (  $sqll ){
echo "<script>alert('Removed');
      window.location='sactivityapprove.php';</script>";
}
else {
	echo "<script>alert('Error');</script>";
}
?>