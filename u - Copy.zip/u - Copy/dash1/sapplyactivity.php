<?php
include 'co.php';
include 'sheader.php';


$lid=$_SESSION['userid'];
if(isset($lid))
{
	$em=$_GET['id'];	
//	echo "<script>alert($lid);</script>";
//echo "<script>alert($em);</script>";
$sql="insert into  applyactivity (userid,activityid,applystatus,apprstatus)values('$lid','$em',1,0)";
if(mysqli_query($co,$sql))
{

echo "<script>alert('Applied');
      window.location='sviewctivity.php'</script>";

}
}
else
header("location:login.php");
?>
