<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
include 'co.php';
include 'poside.php';


$login=$_SESSION['login'];
$type=$_SESSION['type'];

if($login)
{
  ?>
<!DOCTYPE HTML>
<html>
<head>
<title>Add Notices</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Shoppy Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<!--js-->
<script src="js/jquery-2.1.1.min.js"></script> 
<!--icons-css-->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Carrois+Gothic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Work+Sans:400,500,600' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" 
integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" 
integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" 
crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" 
integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
 crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
 integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
 crossorigin="anonymous"></script>






</head>

        
        
          
          

  
    <div class="col-md-4 col-sm-4 col-xs-12 "></div>
    <div class="col-md-4 col-sm-4 col-xs-12  box">
      
        <form name="myform" method="post" class="form-container" id="myform">
          
          <br>
          <h2 ><center>FAQ</center> </h2><br>
            <div class="form-group">
            <label>Questions *</label>
            <input id="fq" name="fq" class="form-control" type="textarea" data-validation="required" rows="10" cols="10">
            <span id="error_notice" class="text-danger"></span>
          </div>
          <br>
            <div class="form-group">
            <label>Answer *</label>
            <input id="fa" name="fa" class="form-control" type="textarea" data-validation="required" rows="5" cols="5">
            <span id="error_notice" class="text-danger"></span>
          </div>
        
          <center><button id="submit" type="submit" name="submit" value="Add Faq" class="btn btn-success center">Add FAQ</button></center>


      
        </form>

      </div>
      
      <div class="col-md-4 col-sm-4 col-xs-12"></div>
    </div >
  </div>
 

  </form>

</font>
 
 


<!--inner block end here-->
<!--pop-up-grid-->
                       <div id="popup">
                <div id="small-dialog" class="mfp-hide">
                    <!-- <div class="pop_up">
                    <div class="payment-online-form-left">
                      <form>
                        <h4><span class="shoppong-pay-1"> </span>Shipping Details</h4>
                        <ul>
                          <li><input class="text-box-dark" type="text" value="First Name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'First Name';}"></li>
                          <li><input class="text-box-dark" type="text" value="Last Name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Last Name';}"></li>
                        </ul>
                        <ul>
                          <li><input class="text-box-dark" type="text" value="Email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email';}"></li>
                          <li><input class="text-box-dark" type="text" value="Phone" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Phone';}"></li>
                        </ul>
                        <ul>
                          <li><input class="text-box-dark" type="text" value="Address" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Address';}"></li>
                          <li><input class="text-box-dark" type="text" value="Pin Code" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Pin Code';}"></li>
                          
                        </ul>
                        <div class="clear"></div>
                        <h4 class="paymenthead"><span class="payment"></span>Payment Details</h4>
                        <div class="clear"></div>                   
                        <ul>
                          <li><input class="text-box-dark" type="text" value="Card Number" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Card Number';}"></li>
                          <li><input class="text-box-dark" type="text" value="Name on card" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Name on card';}"></li>
                        
                        </ul>
                        <ul>
                          <li><input class="text-box-light hasDatepicker" type="text" id="datepicker" value="Expiration Date" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Expiration Date';}"><em class="pay-date"> </em></li>
                          <li><input class="text-box-dark" type="text" value="Security Code" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Security Code';}"></li>
                        
                        </ul>
                        <ul class="payment-sendbtns">
                          <li><input type="reset" value="Reset"></li>
                          <li><a href="#" class="order">Process order</a></li>
                        </ul>
                        <div class="clear"></div>
                      </form>
                    </div>
                    </div>-->
                </div>
                </div>
                
<!--pop-up-grid-->
<!--copy rights start here-->
  
<!--COPY rights end here-->
</div>
</div>
  </form>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js" ></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/3.3.1/jquery-ui.min.js" ></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script>
  jQuery.validator.addMethod("lettersonly", function(value, element) {
  return this.optional(element) || /^[a-z]+$/i.test(value);
}, "Letters only please");
   








var $registrationForm = $('#myform');
if($registrationForm.length){
  $registrationForm.validate({
      rules:{
          //username is the name of the textbox
          fq: {
              required: true,
              //alphanumeric is the custom method, we defined in the above
            
          },
       
        fa: {
              required: true,
              //alphanumeric is the custom method, we defined in the above
             
          },  
          
         
          
      },
      messages:{
          fq: {
              //error message for the required field
              required: 'Enter questions',
           
          },
                 fa: {
              //error message for the required field
              required: 'Enter answers',
           
          },
       
          

      },

  });
}
  </script>



</body>
</html>
<!--slider menu-->
     

<?php
  if(isset($_POST['submit']))
   {
     $fq=$_POST['fq'];
     $fa=$_POST['fa'];
 
 $sq="insert faq (  fquestions,fanswers)values('$fq','$fa')";
if(mysqli_query($co,$sq))
{
  
      echo "<script> alert('Success');
           window.location='faq.php'</script>";
}
}
   
?>
         <?php
}
else
header("location:login.php");
?>          