
<?php
include 'co.php';
include 'sheader.php';
$login=$_SESSION['login'];
$type=$_SESSION['type'];
$usr_name=$_SESSION['name'];
$id=$_SESSION['userid'];
if($login)
{
  ?>

  <?php 
  $sql1=mysqli_query($co,"SELECT `name` FROM `register` WHERE  userid='$id'");
        if($row1=mysqli_fetch_array($sql1))
        $usr_name=$row1['name'];
        $_SESSION['name']=$usr_name;
        
  
  echo "<font size=5 color=blue>Welcome $type  $usr_name";
  ?>

    
     
  


    <body id="home" background="bb.jpg">
    <div class="logo-sidebar">
        <img src="p.jpg" alt="image">
        </div>
 
    <center><h1><u> NOTICE </u></h1></center></table>
			


		<center>		
<table border="1"  cellpadding="10" width="45%"  >
  <tr><th >Matter</th>
   
    
    <th >Date</th>
    <th >Time</th>

	
	 
    
  </tr></center>
<?php
 $q="select * from notice";
 $res=mysqli_query($co,$q);
while($row=mysqli_fetch_assoc($res))
{
	
	

?>

<tr>
<td> 
   <?php 
        echo $row['matter'];
    ?>a
  </td>
  <td> 
   <?php 
        echo $row['date'];
    ?>
  </td>
   <td> 
   <?php 
        echo $row['time'];
    ?>
  </td>



</tr>
<?php
}
?>

</body>

</html>
<?php
}
else
header("location:login.php");
?>
