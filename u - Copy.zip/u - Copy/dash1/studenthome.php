
<?php
include 'sheader.php';

$login=$_SESSION['login'];
$type=$_SESSION['type'];
$usr_name=$_SESSION['name'];$b=$_SESSION['userid'];
if($login)
{
    ?>

  
      <style>
.cities {
  background-color: gray;
  color: white;
  margin: 20px;
  padding: 10px;
  margin-right:20px; 
  margin-top:0.100PX;
}
</style>  
    <script>
    (function($) {
        "use strict";
        $("#menu-toggle").click(function(e) {
            e.preventDefault();
            $("#wrapper").toggleClass("toggled");
        });
        smoothScroll.init({
            selector: '[data-scroll]', // Selector for links (must be a class, ID, data attribute, or element tag)
            selectorHeader: null, // Selector for fixed headers (must be a valid CSS selector) [optional]
            speed: 500, // Integer. How fast to complete the scroll in milliseconds
            easing: 'easeInOutCubic', // Easing pattern to use
            offset: 0, // Integer. How far to offset the scrolling anchor location in pixels
            callback: function ( anchor, toggle ) {} // Function to run after scrolling
        });
    })(jQuery);
    </script>
<body >
    <div class="cities">
  <h3>Your Attendence</h3>
  <p><?php

$res=mysqli_query($co,"select  distinct atte from applyactivity where  userid='$b' and atstatus='1'");
 while($row=mysqli_fetch_assoc($res))
{  
$em=$row['atte'];
echo"$em";
}
?>
  </p>
</div></body>

<?php
}
else
header("location:login.php");
?>
<html>
<body>
    <img src="ann.jpg" width="100%" height="100%" >
    </body>
</html>