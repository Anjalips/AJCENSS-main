<?php
include "co.php";
$b=$_GET['id'];

$sqll=mysqli_query($co,"update   sacti set sstatus='1' where seid='$b'");
if (  $sqll ){
echo "<script>alert('Approved');
      window.location='sactivityapprove.php';</script>";
}
else {
	echo "<script>alert('Error');</script>";
}
?>