<?php
include "co.php";
$b=$_GET['id'];

$res=mysqli_query($co,"select * from applyactivity where userid='$b'");
 while($row=mysqli_fetch_assoc($res))
{  

$et=$row['atte'];
$ett=$et-+70;
}
$sql=mysqli_query($co,"update  applyactivity set atte='$ett',atstatus='1' where userid='$b'");
$sql1=mysqli_query($co,"update  applyapp set ts='0' where userid='$b'");

if ( $sql && $sql1){
echo "<script>alert('Absent');
      window.location='attendence.php';</script>";
}
else {
	echo "<script>alert('Error');</script>";
}
?>



      