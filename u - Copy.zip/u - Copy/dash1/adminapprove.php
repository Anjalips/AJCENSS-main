
<?php
include "co.php";
$em=$_GET['id'];
$sql2="update login set approvedstatus='1' where userid='$em'";
if(mysqli_query($co,$sql2))
{
echo "<script>alert('Approved');
      window.location='approve.php'</script>";
}


if(isset($_POST['submit']))
{
	
		$emailid=$_POST['emailid'];
$sql="SELECT * FROM login WHERE userid='$em'";
	$result=mysqli_query($co,$sql);
	// $row=mysqli_fetch_assoc($result);
	 // $b=$row['emailid'];
	while($row=mysqli_fetch_array($result))
{
$a=$row['emailid'];
}
	if($a==$emailid)
	{
	$e=$a;
	
	$m="selected:";
	
	echo mail("$e","selected","$m");
	//header("location:login.php?message=Authentication Success Please check your mail");
	}
	//else
		echo "hiii";
	//header("location:signin.php?message=Please provide valid informations");
	}
	?>