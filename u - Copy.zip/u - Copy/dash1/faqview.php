
<?php
include 'co.php';
include 'sheader.php'

?>

<!DOCTYPE html>
<html lang="en">

    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">   
   
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
 
     <!-- Site Metas -->
    <title>SMBarber - Responsive HTML5 Template</title>  
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="style.css">
    <!-- Colors CSS -->
    <link rel="stylesheet" href="css/colors.css">
    <!-- ALL VERSION CSS -->
    <link rel="stylesheet" href="css/versions.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  <style>
  .navbar {
    overflow: hidden;
    background-color: gray;
    font-family: Arial, Helvetica, sans-serif;
}
.navbar a.active {
  background-color: #4CAF50;
  color: white;
}

.navbar a {
    float: right;
    font-size: 16px;
    color: white;
    text-align: left;
    padding: 14px 16px;
    text-decoration: none;
}
.navbar a:hover, .dropdown:hover .dropbtn {
    background-color: red;
}
</style>

</head>
<body class="barber_version">
<div class="navbar">

   
     <a href="login.php">Login</a>
       <a href="sregg.php">Sign Up</a>

<a href="index.php">Home</a>


  </div>
<body>	

			

	<font color="black">
		<center>

<div id="sidebar-wrapper" text="white">
			<div class="side-top">
				<div class="logo-sidebar">
				<img src="2jpg.jpg" alt="image">
				</div>
				<ul class="sidebar-nav"></ul></li>
					  <a  href="faqview.php">FAQ</a>

  

                    
                   <li> <a href="gallery.html">Gallery</a></li>
                    
                    <li><a href="history.html">History</a></li>
                    <li><a  href="viewaward.php">Award</a></li>
                    

                    
                    
                  
				</ul>
			</div>
<?php
$select="SELECT * FROM `faq`";
$res=mysqli_query($co,$select);
?>

<?php
while($row=mysqli_fetch_array($res))
{

?>

<h4><?php echo $row['faqid'];?>

<?php echo $row['fquestions'];?></h4>


<h5> &nbsp &nbsp &nbsp<?php echo $row['fanswers'];?></h5>
<?php
}
?>


     
</font>
</body>
</html>
 <?php
}
else
header("location:login.php");
?>          