<?php
include "co.php";
$b=$_GET['id'];
$sql=mysqli_query($co,"update  registers set verifystatus='1' where userid='$b'");
$sqll=mysqli_query($co,"update   login set approvedstatus='0' where userid='$b'");
if ( $sql && $sqll ){
echo "<script>alert('Removed');
      window.location='approve.php';</script>";
}
else {
	echo "<script>alert('Error');</script>";
}
?>
