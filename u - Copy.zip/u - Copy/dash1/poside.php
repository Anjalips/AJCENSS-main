
 
<?php
include 'co.php';


session_start();
$login=$_SESSION['login'];
$type=$_SESSION['type'];

if($login)
{

?>

<!DOCTYPE HTML>
<html>
<head>
<title>Shoppy an Admin Panel Category Flat Bootstrap Responsive Website Template | Price :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Shoppy Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<!--js-->
<script src="js/jquery-2.1.1.min.js"></script> 
<!--icons-css-->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Carrois+Gothic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Work+Sans:400,500,600' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" 
integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" 
integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" 
crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" 
integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
 crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
 integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
 crossorigin="anonymous"></script>





</head>
<body>  
<div class="page-container">  
   <div class="left-content">
     <div class="mother-grid-inner">
            <!--header start here-->
        <div class="header-main">
          <div class="header-left">
              <div class="logo-name">
                   <a href="programofficerhome.php"> <h1>AJCE NSS</h1> 
                  <!--<img id="logo" src="" alt="Logo"/>--> 
                  </a>                
              </div>                                            
             </div>
             <div class="header-right">
              
              <!--notification menu end -->
              <div class="profile_details">   
                <ul>
                  <li class="dropdown profile_details_drop">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                      <div class="profile_img"> 
                        <span class="prfil-img"><img src="images/p1.png" alt=""> </span> 
                        <div class="user-name">
                        
                          <span><?php echo "<font size=5 color=blue>Welcome $type ";?></span>
                </span>
                        </div>
                        <i class="fa fa-angle-down lnr"></i>
                        <i class="fa fa-angle-up lnr"></i>
                        <div class="clearfix"></div>  
                      </div>  
                    </a>
                   
                    <ul class="dropdown-menu drp-mnu">
                      
                      <!--<li> <a href="#"><i class="fa fa-user"></i> Profile</a> </li> -->
                      <li> <a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a> </li>
                    </ul>
                  </li>
                </ul>
              </div>          
            </div>
             <div class="clearfix"> </div>  
        </div>
        
        
          
          


 <h2><center></center></h2><br>
<div class="inner-block1"><br></div>
<div class="container-fluid ">
<div class="row">
  
    <div class="col-md-4 col-sm-4 col-xs-12 "></div>
    <div class="col-md-4 col-sm-4 col-xs-12  box">
      
        
      </div>
      
      <div class="col-md-4 col-sm-4 col-xs-12"></div>
    </div >
  </div>
 

  </form>

</font>
 
 


<!--inner block end here-->
<!--pop-up-grid-->
                       <div id="popup">
                <div id="small-dialog" class="mfp-hide">
                   
</div>
</div>
 <div class="sidebar-menu">
        <div class="logo"> <a href="programofficerhome.php" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> <a href="#"> <span id="logo" ></span> 
            <!--<img id="logo" src="" alt="Logo"/>--> 
        </a> </div>     
        <div class="menu">
          <ul id="menu" >
            <li id="menu-home" ><a href="programofficerhome.php"><i class="fa fa-tachometer"></i><span>Home</span></a></li>
            <li><a href="#"><i class="fa fa-cogs"></i><span>Add</span><span class="fa fa-angle-right" style="float: right"></span></a>
              <ul>
                <li><a href="award.php">Award</a></li>
                <li><a href="notice.php">Notice</a></li>  
           <li><a href="faq.php">FAQ</a></li>  
          
      <li><a href="addvs.php">New Volunteer Secretary
      </a></li>  
      
              </ul>
        <li><a href="#"><i class="fa fa-cogs"></i><span>Approve</span><span class="fa fa-angle-right" style="float: right"></span></a>
              <ul>
                <li><a href="approve.php">New Request</a></li>
                <li><a href="approveapp.php">New Application</a></li> 
          <li><a href="approveactivity.php">New Activity</a></li>
                <li><a href="poapplystudents.php">Activity Participants List</a></li>  
           <li><a href="poapprovestudents.php">  Application Participants List</a></li>  
          <li><a href="sactivityapprove.php">  Seven day camp activities</a></li> 
      <li><a href="eregisterapprove.php">  Candidate approve</a></li>
              </ul>
            </li>
            <li><a href="#"><i class="fa fa-cogs"></i><span>histories</span><span class="fa fa-angle-right" style="float: right"></span></a>
              <ul>
                
            <li ><a href="shistory.php">students history</span></a></li>
            <li ><a href="aahistory.php">Application history</span></a></li>
            <li ><a href="ahistory.php">Activity history</span></a></li>
             
                  
          
      
      
              </ul>
            </li>
           <li><a href="#"><i class="fa fa-cogs"></i><span>Views</span><span class="fa fa-angle-right" style="float: right"></span></a>
              <ul>
                
            <li ><a href="suggestion2.php">Suggestion</span></a></li>
            <li ><a href="viewatt.php">Attendence</span></a></li>
            <li ><a href="poview.php">Sevenday Activities </span></a></li>
             
                 <li><a href="eresult.php">Election Result</a></li>   
          
      
      
              </ul>
            </li>
            
  
        
      <li><a href="imgview.php"><i class="fa fa-cog"></i><span>Gallery</span></a>
            
           <li><a href="pchangepw.php"><i class="fa fa-cog"></i><span>Change Password</span></a>
             <li> <a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a> </li>  
            
      </ul>
        </div>
   </div>
  <div class="clearfix"> </div>
</div>
<!--slide bar menu end here-->
<script>
var toggle = true;
            
$(".sidebar-icon").click(function() {                
  if (toggle)
  {
    $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
    $("#menu span").css({"position":"absolute"});
  }
  else
  {
    $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
    setTimeout(function() {
      $("#menu span").css({"position":"relative"});
    }, 400);
  }               
                toggle = !toggle;
            });
</script>


</body>
</html>
<?php
}
else
header("location:login.php");
?>