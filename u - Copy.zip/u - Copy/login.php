
<!DOCTYPE html>
<html>
<head>
<title>login</title>
<link rel="stylesheet" href="n.css">
<script>

function validateform()
{




var emailid = /^([a-z0-9A-Z_\.\-])+\@(([a-zA-Z\-])+\.)+([a-zA-Z]{2,4})+$/;
var c=document.myform.username.value;
 if(c==null || c=="")
	   {
	   alert("username can't be empty");
	   return false;
	   }
    if (!emailid.test(document.myform.username.value)) {
    alert('Please provide a valid username');
    emailid.focus;
    return false;
 } 

 
    if(myform.password.value != "") {
      if(myform.password.value.length < 5) {
        alert("Error: Password must contain at least five characters!");
        myform.password.focus();
        return false;
      }
      
      re = /[0-9]/;
      if(!re.test(myform.password.value)) {
        alert("Error: password must contain at least one number (0-9)!");
        myform.password.focus();
        return false;
      }
      re = /[a-z]/;
      if(!re.test(myform.password.value)) {
        alert("Error: password must contain at least one lowercase letter (a-z)!");
        myform.password.focus();
        return false;
      }
      re = /[A-Z]/;
      if(!re.test(myform.password.value)) {
        alert("Error: password must contain at least one uppercase letter (A-Z)!");
        myform.password.focus();
        return false;
      }
    } else {
      alert("Error: Please check that you've entered  your password!");
      myform.password.focus();
      return false;
    }

    return true;
 
}
</script>
</head>
<body background="k.png" text="white">
<div class="h1" >
<form name="myform" action="login.php" onsubmit="return validateform()" method="post">

</div>
<div class="box">
<h2>login</h2>
<form method="post" action="login.php">
<div class="inputBox">
<label>USERNAME</label>
<input type="text" name="username" >
</div>
<div class="inputBox">
<label>PASSWORD</label>
<input type="password" name="password" >

</div>
<input type="submit" name="submit" value="Submit">

<table>
 <tr>
        <td>
                 
        
               New User? <a href="sregg.php">Register</a>
        </td><td>
                 
        
        </td>
        </tr>
		</table>
</form>
</div>

</body>
</html>
<?php 
session_start(); 


include ("co.php");
if(isset($_POST['submit']))
{
    $uname =$_POST['username'];
	$pass =$_POST['password'];
//echo $u_pass;
$p=md5($pass);

$sql="select * from login where emailid='$uname' and password='$p' ";
//echo $sq;

$result=mysqli_query($co,$sql);
$rowcount=mysqli_num_rows($result);
if($rowcount!=0)
{

	while($row=mysqli_fetch_array($result))
	{
		$dbu_name=$row['emailid'];
		$dbu_pass=$row['password'];
		$dbu_type=$row['usertype'];
		$id=$row['userid'];
		$i=$row['approvedstatus'];

        
		if($dbu_name==$uname && $dbu_pass==$p)
		{
			$_SESSION['username']=$dbu_name;
            $_SESSION['password']=$dbu_pass;
            $_SESSION['login']="1";
            $_SESSION['userid']=$id;
			$_SESSION['approvedstatus']=$i;

		     //echo $dbu_type;
			if($dbu_type==0 )	
			{
				$_SESSION['type']="Admin";
				
				
               	header('Location: adminhome.php');
			}
			else if($dbu_type==3 && $i==1)
			{
				$_SESSION['type']="Student";
				$sql1="select  * from register where userid ='$id'";
				$result1=mysqli_query($co,$sql1);
				if($row1=mysqli_fetch_array($result1))
				$usr_name=$row1['name'];
				$_SESSION['name']=$usr_name;
                	header('Location: studenthome.php');
			}
			else if($dbu_type==1 )
			{
				$_SESSION['type']="Programofficer";
				
				
               	header('Location: programofficerhome.php');
			}
			else if($dbu_type==2 )
			{
				$_SESSION['type']="Volunteer Secretary";
				
				$_SESSION['name']=$usr_name;
               	header('Location: volunteersechome.php');
			}
		
		else
        {
echo " <script> alert('invalid login credentials');
window.location='login.php';
</script>";
			//	header("location:login.php?error=wrong password");
         // echo "not approved";
        }
	}
}
}
else
{?>
	<script>
 alert("User not found");
 window.location='login.php'
</script>;
<?php
			//header("location:signin.php?error=User Not Found");
			//echo "not found";	
}
}
?>	
